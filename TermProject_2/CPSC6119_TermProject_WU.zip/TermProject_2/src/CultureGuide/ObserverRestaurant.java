package CultureGuide;

public interface ObserverRestaurant {
	//void updateFrom();
	void updateTo();
        void updateAge();
	
}
