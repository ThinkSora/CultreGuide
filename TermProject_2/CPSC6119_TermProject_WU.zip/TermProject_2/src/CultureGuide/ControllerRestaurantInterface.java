package CultureGuide;

public interface ControllerRestaurantInterface {
    void getMenu();
    void orderAlcohol();

}
