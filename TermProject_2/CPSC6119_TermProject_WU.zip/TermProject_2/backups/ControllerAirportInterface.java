package CultureGuide;

public interface ControllerAirportInterface {
		void callTaxi();
		void callUber();
		void toPay();
}
