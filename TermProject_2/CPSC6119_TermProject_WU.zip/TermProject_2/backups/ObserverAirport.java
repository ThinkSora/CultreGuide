package CultureGuide;

public interface ObserverAirport {
	void updateFrom();
	void updateHotel();
	void updateCurrency();
	void updatePay();
}
