package CultureGuide;

public interface ObserverHotel {
	void updateAge();
	void updatePay();
	void updateCheckOut();
}
